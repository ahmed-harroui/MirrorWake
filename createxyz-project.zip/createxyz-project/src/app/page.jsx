"use client";
import React from "react";

import { useUpload } from "../utilities/runtime-helpers";

function MainComponent() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [alarms, setAlarms] = useState([]);
  const [showAddAlarm, setShowAddAlarm] = useState(false);
  const [newAlarmTime, setNewAlarmTime] = useState("07:00");
  const [selectedDays, setSelectedDays] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [photos, setPhotos] = useState([]);
  const [showCamera, setShowCamera] = useState(false);
  const [selectedAlarmId, setSelectedAlarmId] = useState(null);
  const [upload, { loading: uploadLoading }] = useUpload();
  const daysOfWeek = [
    "Lundi",
    "Mardi",
    "Mercredi",
    "Jeudi",
    "Vendredi",
    "Samedi",
    "Dimanche",
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    fetchAlarms();
  }, []);

  const fetchAlarms = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/alarms/list", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });

      if (!response.ok) {
        throw new Error("Erreur lors de la récupération des alarmes");
      }

      const data = await response.json();
      setAlarms(data.alarms || []);
      setPhotos(data.photos || []);
    } catch (err) {
      setError("Impossible de charger les alarmes");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  const handleCreateAlarm = async () => {
    try {
      const response = await fetch("/api/alarms/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          time: newAlarmTime,
          days_of_week: selectedDays.join(","),
        }),
      });

      if (!response.ok) {
        throw new Error("Erreur lors de la création de l'alarme");
      }

      await fetchAlarms();
      setShowAddAlarm(false);
      setNewAlarmTime("07:00");
      setSelectedDays([]);
    } catch (err) {
      setError("Impossible de créer l'alarme");
      console.error(err);
    }
  };
  const toggleDay = (day) => {
    setSelectedDays((prev) =>
      prev.includes(day) ? prev.filter((d) => d !== day) : [...prev, day]
    );
  };
  const handleTakePhoto = async (alarmId) => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      const video = document.createElement("video");
      video.srcObject = stream;
      await video.play();

      const canvas = document.createElement("canvas");
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      canvas.getContext("2d").drawImage(video, 0, 0);

      stream.getTracks().forEach((track) => track.stop());

      const blob = await new Promise((resolve) =>
        canvas.toBlob(resolve, "image/jpeg")
      );
      const file = new File([blob], "wake-photo.jpg", { type: "image/jpeg" });

      const { url: imageUrl, error: uploadError } = await upload({ file });
      if (uploadError) throw new Error(uploadError);

      const verificationResult = await fetch("/api/verify-letters", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ image: imageUrl }),
      }).then((r) => r.json());

      if (verificationResult.success) {
        await fetch("/api/photos/save", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            alarm_id: alarmId,
            photo_url: imageUrl,
          }),
        });

        setShowCamera(false);
        setSelectedAlarmId(null);
        await fetchAlarms();
      } else {
        setError(verificationResult.message);
      }
    } catch (err) {
      console.error(err);
      setError("Erreur lors de la prise de photo");
    }
  };

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 p-4 md:p-8">
      {/* Heure actuelle */}
      <div className="text-center mb-12">
        <h1 className="text-6xl md:text-8xl font-bold text-gray-900 dark:text-white font-inter">
          {currentTime.toLocaleTimeString("fr-FR", {
            hour: "2-digit",
            minute: "2-digit",
          })}
        </h1>
      </div>

      {/* Section Alarmes */}
      <div className="mb-12">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white font-inter">
            Mes Alarmes
          </h2>
          <button
            onClick={() => setShowAddAlarm(true)}
            className="bg-gray-900 dark:bg-white text-white dark:text-gray-900 rounded-md px-4 py-2 font-inter"
          >
            <i className="fas fa-plus mr-2"></i>
            Ajouter
          </button>
        </div>

        {loading ? (
          <div className="animate-pulse space-y-4">
            <div className="h-16 bg-gray-200 dark:bg-gray-700 rounded-md"></div>
            <div className="h-16 bg-gray-200 dark:bg-gray-700 rounded-md"></div>
          </div>
        ) : error ? (
          <div className="text-red-500 dark:text-red-400 text-center py-4">
            {error}
          </div>
        ) : alarms.length === 0 ? (
          <div
            className="bg-gray-50 dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-100 dark:border-gray-700 
  flex flex-col items-center justify-center text-center cursor-pointer"
            onClick={() => setShowAddAlarm(true)}
          >
            <span className="text-4xl mb-2">📅</span>
            <p className="text-gray-500 dark:text-gray-400">
              Ajouter une alarme
            </p>
          </div>
        ) : (
          <div className="grid gap-4">
            {alarms.map((alarm) => (
              <div
                key={alarm.id}
                className="bg-gray-50 dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-100 dark:border-gray-700"
              >
                <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center">
                    <span className="text-2xl mr-2">🔔</span>
                    <div>
                      <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                        Alarme {alarm.id}
                      </h3>
                      <p className="text-gray-500 dark:text-gray-400">
                        Jours : {alarm.days_of_week || "Non défini"}
                      </p>
                      <p className="text-gray-500 dark:text-gray-400">
                        Heure : {alarm.time}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      setSelectedAlarmId(alarm.id);
                      setShowCamera(true);
                    }}
                    className="bg-gray-900 dark:bg-white text-white dark:text-gray-900 px-4 py-2 rounded-md"
                  >
                    <i className="fas fa-camera mr-2"></i>
                    Désactiver
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {showCamera && (
          <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg w-full max-w-lg">
              <h3 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">
                Prendre une photo
              </h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                Assurez-vous que les lettres "M" et "W" sont visibles dans la
                photo
              </p>
              <div className="flex justify-end gap-4">
                <button
                  onClick={() => {
                    setShowCamera(false);
                    setSelectedAlarmId(null);
                  }}
                  className="px-4 py-2 border border-gray-200 dark:border-gray-700 rounded-md"
                >
                  Annuler
                </button>
                <button
                  onClick={() => handleTakePhoto(selectedAlarmId)}
                  className="bg-gray-900 dark:bg-white text-white dark:text-gray-900 px-4 py-2 rounded-md"
                >
                  Capturer
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Modal Nouvelle Alarme */}
      {showAddAlarm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md">
            <h3 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">
              Nouvelle Alarme
            </h3>

            <input
              type="time"
              value={newAlarmTime}
              onChange={(e) => setNewAlarmTime(e.target.value)}
              className="w-full mb-4 p-2 border border-gray-200 dark:border-gray-700 rounded-md"
            />

            <div className="mb-4">
              <div className="flex flex-wrap gap-2">
                {daysOfWeek.map((day, index) => (
                  <button
                    key={day}
                    onClick={() => toggleDay(day)}
                    className={`px-3 py-1 rounded-md ${
                      selectedDays.includes(day)
                        ? "bg-gray-900 dark:bg-white text-white dark:text-gray-900"
                        : "bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white"
                    }`}
                  >
                    {day.substring(0, 3)}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex justify-end gap-4">
              <button
                onClick={() => setShowAddAlarm(false)}
                className="px-4 py-2 border border-gray-200 dark:border-gray-700 rounded-md text-gray-900 dark:text-white"
              >
                Annuler
              </button>
              <button
                onClick={handleCreateAlarm}
                className="px-4 py-2 bg-gray-900 dark:bg-white text-white dark:text-gray-900 rounded-md"
              >
                Sauvegarder
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Section Photos */}
      <div className="mb-12">
        <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white font-inter">
          Mes Photos
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {photos.map((photo) => (
            <div
              key={photo.id}
              className="bg-gray-50 dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm border border-gray-100 dark:border-gray-700"
            >
              <div className="aspect-square relative">
                <img
                  src={photo.photo_url}
                  alt={`Photo ${photo.id}`}
                  className="object-cover w-full h-full"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-75 text-white p-4">
                  <div className="flex items-center">
                    <span className="text-xl mr-2">📸</span>
                    <div>
                      <p className="font-semibold">Photo {photo.id}</p>
                      <p className="text-sm">
                        {new Date(photo.taken_at).toLocaleDateString("fr-FR", {
                          day: "2-digit",
                          month: "2-digit",
                          year: "numeric",
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
          {photos.length === 0 && (
            <div
              className="bg-gray-50 dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-100 dark:border-gray-700 
        flex flex-col items-center justify-center text-center aspect-square"
            >
              <span className="text-4xl mb-2">📷</span>
              <p className="text-gray-500 dark:text-gray-400">
                Prendre une photo
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default MainComponent;